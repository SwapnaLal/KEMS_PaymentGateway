﻿namespace KEMS_ADMISSION.Pages
{
    internal class DBO
    {
    }
}